<template>
  <router-view />
</template>